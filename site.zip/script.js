const schedule = [
  { time: "08:20", title: "Abertura"},
  { time: "08:30 - 09:20", title: "Linux Sandboxing: Introdução, Técnicas e Escaping - Gildásio Jr", speaker: "Gildásio Jr.", tag: "Palestra 1" },
  { time: "09:30 - 10:20", title: "Windows Process Injection - DIY", speaker: "Alan Lacerda", tag: "Palestra 2" },
  { time: "10:30 - 11:20", title: "Compromentendo a segurança de um ERP utilizado por provedores de Internet", speaker: "Yueslly Lisboa", tag: "Palestra 3" },
  { time: "11:30 - 12:50:", title: "Almoço"},
  { time: "13:00 - 13:50", title: " Hacking iOS Apps", speaker: "Fernando Pinheiro", tag: "Palestra 4" },
  { time: "14:00 - 14:50", title: "Quando o ps mente: detecção de rootkits na camada do kernel", speaker: "Victor Mascarenhas", tag: "Palestra 5" },
  { time: "14:50 - 15:05", title: "Coffee-Break"},
  { time: "15:10 - 16:00", title: "O PHP está morto?", speaker: "Obtuosa", tag: "Palestra 6" },
  { time: "16:10 - 17:00", title: "Cloud Security Hunting: Misconfigurations, Identities & Attack Paths", speaker: "Alexandro Silva (Alexos)", tag: "Palestra 7" },
  { time: "17:10", title: "Encerramento & Premiações"},
];

const speakers = [
  { name: "Gildásio Jr"},
  { name: "Alan Lacerda"},
  { name: "Yueslly Lisboa"},
  { name: "Fernando Pinheiro"},
  { name: "Victor Mascarenhas"},
  { name: "Obtuosa"},
  { name: "Alexandro Silva (Alexos)"},
];

const sponsors = [
  // Adicione patrocinadores aqui quando os apoios forem confirmados.
  // { tier: "Ouro", className: "gold", names: ["Nome do patrocinador"] },
  // { tier: "Prata", className: "silver", names: ["Nome do patrocinador"] },
  // { tier: "Bronze", className: "bronze", names: ["Nome do patrocinador"] },
];

const supporters = [
  {
    name: "Nullbyte Security Conference",
    url: "https://www.nullbyte-con.org/",
    logo: "assets/apoiadores/1.png",
  },
  {
    name: "CajuSec",
    url: "https://www.cajusec.com.br/",
    logo: "assets/apoiadores/2.png",
  },
  {
    name: "Oxe Hacker Conference",
    url: "https://conference.oxehc.com.br/",
    logo: "assets/apoiadores/3.png",
  },
  {
    name: "Raul Hacker Club",
    url: "https://raulhc.cc/",
    logo: "assets/apoiadores/4.png",
  },
  {
    name: "AxéSec",
    url: "https://axesec.cc/",
    logo: "assets/apoiadores/5.png",
  },

   {
    name: "Donas Security",
    url: "https://www.instagram.com/donasecurity/",
    logo: "assets/apoiadores/6.png",
  },
];

function renderSchedule() {
  document.querySelector("#schedule").innerHTML = schedule.map((item) => `
    <article class="schedule-row">
      <div class="time">${item.time}</div>
      <div><span class="schedule-title">${item.title}</span><span class="tag ${item.tag}">[${item.tag}]</span></div>
      <div class="speaker-meta">${item.speaker}</div>
    </article>
  `).join("");
}

function renderSpeakers() {
  document.querySelector("#speakers").innerHTML = speakers.map((speaker, index) => `
    <article class="speaker-card ${speaker.featured ? "featured" : ""}" data-initials="${speaker.initials}">
      <span class="speaker-index">${String(index + 1).padStart(2, "0")}</span>
      <div class="speaker-avatar">${speaker.initials}</div>
      <h3>${speaker.name}</h3>
      <p>${speaker.role}</p>
      <small>${speaker.years}</small>
    </article>
  `).join("");
}

function renderSponsors() {
  const sponsorTarget = document.querySelector("#sponsors");

  sponsorTarget.innerHTML = sponsors.length
    ? sponsors.map((tier) => `
      <div class="sponsor-tier">
        <div class="tier-name ${tier.className}">${tier.tier}</div>
        <div class="sponsor-list">${tier.names.map((name) => `<span class="sponsor-pill">${name}</span>`).join("")}</div>
      </div>
    `).join("")
    : `
      <div class="sponsor-callout">
        <span>// cotas abertas</span>
        <h3>Seja um patrocinador</h3>
        <p>Apoie a edição de 10 anos do HackBahia e conecte sua marca à comunidade de segurança da informação.</p>
        <a href="mailto:contato@hackbahia.com.br?subject=Patrocínio%20HackBahia" class="button button-ghost">Falar com a organização</a>
      </div>
    `;

  document.querySelector("#supporters").innerHTML = supporters.map((supporter) => `
    <a class="supporter-card" href="${supporter.url}" target="_blank" rel="noopener noreferrer" aria-label="${supporter.name}">
      <img src="${supporter.logo}" alt="${supporter.name}" loading="lazy">
    </a>
  `).join("");
}

function setupMenu() {
  const button = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  button.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    button.setAttribute("aria-expanded", String(isOpen));
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      button.setAttribute("aria-expanded", "false");
    });
  });
}

function setupHeader() {
  const header = document.querySelector(".site-header");
  const sync = () => header.classList.toggle("scrolled", window.scrollY > 20);
  sync();
  window.addEventListener("scroll", sync, { passive: true });
}

function setupCountdown() {
  const target = new Date("2026-09-26T09:00:00-03:00").getTime();
  const countdown = document.querySelector("#countdown");

  function render() {
    const diff = Math.max(0, target - Date.now());
    const values = [
      { value: Math.floor(diff / 86400000), label: "D" },
      { value: Math.floor((diff % 86400000) / 3600000), label: "H" },
      { value: Math.floor((diff % 3600000) / 60000), label: "M" },
      { value: Math.floor((diff % 60000) / 1000), label: "S" },
    ];

    countdown.innerHTML = values.map((item, index) => `
      <span class="countdown-block">
        <strong>${String(item.value).padStart(2, "0")}</strong><span>${item.label}</span>
      </span>
      ${index < values.length - 1 ? '<span class="countdown-sep">:</span>' : ""}
    `).join("");
  }

  render();
  setInterval(render, 1000);
}

function setupReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add("visible"), entry.target.dataset.delay || 0);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.16 });
  document.querySelectorAll(".reveal").forEach((item) => observer.observe(item));
}

// renderSchedule();
// renderSpeakers();
renderSponsors();
setupMenu();
setupHeader();
setupCountdown();
setupReveal();
